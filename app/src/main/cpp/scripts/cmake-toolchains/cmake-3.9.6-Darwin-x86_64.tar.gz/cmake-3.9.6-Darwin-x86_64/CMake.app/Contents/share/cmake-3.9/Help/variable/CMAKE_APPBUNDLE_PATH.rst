CMAKE_APPBUNDLE_PATH
--------------------

:ref:`;-list <CMake Language Lists>` of directories specifying a search path
for OS X application bundles used by the :command:`find_program`, and
:command:`find_package` commands.
