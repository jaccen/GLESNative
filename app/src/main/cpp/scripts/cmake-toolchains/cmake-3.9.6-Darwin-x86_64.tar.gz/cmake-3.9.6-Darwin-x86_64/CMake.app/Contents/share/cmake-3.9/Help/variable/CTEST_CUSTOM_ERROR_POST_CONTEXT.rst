CTEST_CUSTOM_ERROR_POST_CONTEXT
-------------------------------

The number of lines to include as context which follow an error message by the
:command:`ctest_test` command. The default is 10.

.. include:: CTEST_CUSTOM_XXX.txt
