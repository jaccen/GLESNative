CTEST_CUSTOM_POST_TEST
----------------------

A list of commands to run at the end of the :command:`ctest_test` command.

.. include:: CTEST_CUSTOM_XXX.txt
