CTEST_USE_LAUNCHERS
-------------------

Specify the CTest ``UseLaunchers`` setting
in a :manual:`ctest(1)` dashboard client script.
