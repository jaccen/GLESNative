CMAKE_SKIP_INSTALL_RULES
------------------------

Whether to disable generation of installation rules.

If ``TRUE``, cmake will neither generate installaton rules nor
will it generate ``cmake_install.cmake`` files. This variable is ``FALSE`` by
default.
